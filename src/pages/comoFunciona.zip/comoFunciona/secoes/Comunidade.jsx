import { FaLeaf, FaHeart, FaComment, FaPlay } from "react-icons/fa";

import Thumb from "../../../components/comofunciona/Thumb";
import LockedAction from "../../../components/comofunciona/LockedAction";
import PerfilTabs from "../../../components/comofunciona/PerfilTabs";

import {
  artigosComunidade,
  videos,
  guias,
  extras,
} from "./ComunidadeData";

export default function Comunidade({

  onEntrar = () => console.log("entrar"),
  onCriarConta = () => console.log("criar conta"),
}) {
  return (
    <section id="comunidade" className="cq-comunidade">
      <div className="section-inner">

        <span className="cq-eyebrow">
          05 · muito além da reciclagem
        </span>

        <h2>A comunidade continua depois do login.</h2>

        <p className="cq-intro">
          O <strong>Recicla que Pontua</strong> não é só um mapa de pontos de
          coleta. É também onde participantes contam o que aprenderam, a equipe
          publica guias e vídeos, e você acompanha seu próprio impacto.
          Dá pra ler, assistir e navegar por tudo isso sem conta — só curtir e
          comentar ficam para depois do login.
        </p>

        <div className="cq-layout">

          {/* Sidebar */}
          <aside className="cq-side">

            <div className="cq-side-label">
              Escrito pela comunidade
            </div>

            <p className="cq-side-sub">
              Matérias enviadas por participantes do Recicla que Pontua.
            </p>

            {artigosComunidade.map((artigo) => (
              <div
                key={artigo.titulo}
                className="cq-article-card"
                onClick={onCriarConta}
              >
                <Thumb
                  icone={artigo.icone}
                  cor={artigo.cor}
                  size="sm"
                />

                <div>
                  <h4>{artigo.titulo}</h4>

                  <div className="cq-article-meta">
                    por <b>{artigo.autor}</b>
                  </div>

                  <span className="cq-tag-participante">
                    {artigo.tag}
                  </span>
                </div>
              </div>
            ))}

          </aside>

          {/* Conteúdo principal */}

          <div className="cq-main">

            {/* Destaque */}

            <section>

              <div className="cq-block-head">
                <h3>Em destaque</h3>
              </div>

              <div className="cq-featured">

                <Thumb
                  icone={<FaLeaf />}
                  cor="b"
                  size="lg"
                />

                <div className="cq-featured-body">

                  <span className="cq-side-label">
                    Reportagem
                  </span>

                  <h2 className="fh">
                    De onde vem o que você recicla: uma visita aos centros parceiros
                  </h2>

                  <p className="fh-sub">
                    Acompanhamos uma tarde na cooperativa Vida Verde para entender
                    o que acontece com o material depois que ele sai da sua casa.
                  </p>

                  <div className="cq-featured-foot">

                    <button
                      className="cq-read-arrow"
                      onClick={onCriarConta}
                    >
                      Ler matéria completa
                      <span className="arrow"> → </span>
                    </button>

                    <div className="cq-actions-row">
                      <LockedAction
                        icon={<FaHeart />}
                        label="Curtir"
                        count={128}
                      />

                      <LockedAction
                        icon={<FaComment />}
                        label="Comentar"
                        count={14}
                      />
                    </div>

                  </div>

                </div>

              </div>

            </section>

            {/* Vídeos */}

            <section>

              <div className="cq-block-head">
                <h3>Vídeos</h3>

                <button
                  className="link-btn"
                  onClick={onCriarConta}
                >
                  Ver todos
                </button>
              </div>

              <div className="cq-video-grid">

                {videos.map((video) => (

                  <div
                    key={video.titulo}
                    className="cq-video-card"
                  >

                    <div className="cq-video-thumb-wrap">

                      <Thumb
                        icone={video.icone}
                        cor={video.cor}
                        size="md"
                      />

                      <div className="cq-video-play">
                        <FaPlay />
                      </div>

                      <div className="cq-video-duration">
                        {video.duracao}
                      </div>

                    </div>

                    <h4>{video.titulo}</h4>

                    <div className="cq-video-foot">

                      <span>
                        Centro de aprendizagem
                      </span>

                      <LockedAction
                        icon={<FaHeart />}
                        label="Curtir"
                      />

                    </div>

                  </div>

                ))}

              </div>

            </section>

            {/* Guias */}

            <section>

              <div className="cq-block-head">

                <h3>Guias</h3>

                <button
                  className="link-btn"
                  onClick={onCriarConta}
                >
                  Ver todos
                </button>

              </div>

              <div className="cq-guide-grid">

                {guias.map((guia) => (

                  <div
                    key={guia.titulo}
                    className="cq-guide-card"
                    onClick={onCriarConta}
                  >

                    <div className="cq-guide-top">

                      <span className="cq-guide-icon">
                        {guia.icone}
                      </span>

                      <span className="cq-guide-level">
                        {guia.nivel}
                      </span>

                    </div>

                    <h4>{guia.titulo}</h4>

                    <div className="cq-guide-meta">
                      <span>{guia.aulas} aulas</span>
                      <span>{guia.duracao}</span>
                    </div>

                    <div className="cq-guide-bar">
                      <span />
                    </div>

                    <div className="cq-guide-cta">
                      Crie uma conta para acompanhar seu progresso.
                    </div>

                  </div>

                ))}

              </div>

            </section>

            {/* Impacto */}

            <section className="cq-impact">

              <div className="cq-impact-stat">
                <b>12kg</b>
                <span>reciclados</span>
              </div>

              <div className="cq-impact-stat">
                <b>340</b>
                <span>pontos</span>
              </div>

              <div className="cq-impact-stat">
                <b>3</b>
                <span>medalhas</span>
              </div>

              <div className="cq-impact-note">
                Esses números são apenas um exemplo.

                <button
                  className="link-btn"
                  onClick={onCriarConta}
                >
                  Crie uma conta
                </button>

                {" "}para acompanhar seu impacto real.

              </div>

            </section>

            {/* Extras */}

            <section>

              <div className="cq-block-head">
                <h3>E também</h3>
              </div>

              <div className="cq-extras-grid">

                {extras.map((extra) => (

                  <div
                    key={extra.titulo}
                    className="cq-extra-card"
                  >

                    <span className="cc-icon">
                      {extra.icone}
                    </span>

                    <h4>{extra.titulo}</h4>

                    <p>{extra.texto}</p>

                  </div>

                ))}

              </div>

            </section>

          </div>

        </div>

        {/* Perfis */}

        <PerfilTabs />

        {/* CTA */}

        <div className="cq-locked-wrap">

          <div className="locked-card">

            <div className="lc-divider" />

            <div>

              <div className="lc-eyebrow">
                Crie sua conta
              </div>

              <h3>
                Para curtir, comentar e ver seu impacto de verdade
              </h3>

              <p>
                Você já pode navegar por todo o conteúdo.
                Criando uma conta, poderá comentar,
                curtir publicações, conversar com outros usuários
                e acompanhar sua evolução.
              </p>

              <div className="lc-actions">

                <button
                  className="btn-primary"
                  onClick={onCriarConta}
                >
                  Quero participar →
                </button>

                <button
                  className="btn-secondary"
                  onClick={onEntrar}
                >
                  Já tenho conta
                </button>

              </div>

            </div>

            <div className="lc-seal">

              <div className="lc-seal-inner">

                <span className="lc-seal-icon">
                  <FaLeaf />
                </span>

                <span className="lc-seal-text">
                  acesso
                  <br />
                  exclusivo
                </span>

              </div>

            </div>

          </div>

        </div>

      </div>
    </section>
  );
}