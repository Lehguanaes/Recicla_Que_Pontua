export const perfis = [
    { id: "reciclador", label: "Pessoa recicladora", resumo: "Notícias, dicas práticas, desafios semanais e um painel do seu impacto ambiental acumulado." },
    { id: "catador", label: "Catador", resumo: "Solicitações de coleta na sua região, novas oportunidades, mensagens e estatísticas de atendimento." },
    { id: "centro", label: "Centro de reciclagem", resumo: "Gestão dos materiais aceitos, indicadores de coleta e canal direto com os usuários da plataforma." },
    { id: "instituicao", label: "Instituição de ensino", resumo: "Acompanhamento de campanhas internas, ranking entre escolas e desempenho dos participantes." },
  ];

export const artigosComunidade = [
    { titulo: "Como reduzi meu lixo em 60% em 3 meses", autor: "Rafael Tavares", tag: "participante", icone: "🧴", cor: "a" },
    { titulo: "Composteira de apartamento: o que aprendi errando", autor: "Beatriz Lima", tag: "participante", icone: "🪱", cor: "b" },
    { titulo: "Levei a reciclagem pra escola dos meus filhos", autor: "Diego Andrade", tag: "participante", icone: "🎒", cor: "c" },
    { titulo: "5 potes de vidro que reaproveito toda semana", autor: "Sofia Martins", tag: "participante", icone: "🫙", cor: "a" },
  ];

export const videos = [
    { titulo: "Como higienizar embalagens antes de reciclar", duracao: "4:12", icone: "🧽", cor: "b" },
    { titulo: "Plástico, vidro, papel: o que pode e o que não pode", duracao: "6:03", icone: "♻️", cor: "c" },
    { titulo: "Compostagem em 5 passos simples", duracao: "5:47", icone: "🌱", cor: "a" },
  ];

export const guias = [
    { titulo: "Reciclagem para iniciantes", nivel: "Iniciante", aulas: 6, duracao: "45 min", icone: "📗" },
    { titulo: "Compostagem doméstica", nivel: "Intermediário", aulas: 8, duracao: "1h10", icone: "📙" },
    { titulo: "Educação ambiental em sala de aula", nivel: "Educadores", aulas: 5, duracao: "40 min", icone: "📘" },
  ];

export const extras = [
    { icone: "📅", titulo: "Eventos", texto: "Mutirões, feiras e campanhas perto de você." },
    { icone: "🌎", titulo: "Curiosidades", texto: "Tempo de decomposição e dados de reciclagem." },
    { icone: "❤️", titulo: "Projetos parceiros", texto: "Cooperativas e ONGs parceiras da plataforma." },
    { icone: "🤖", titulo: "Assistente virtual", texto: "Tira dúvidas sobre descarte, na hora." },
  ];
