import { useState } from "react";
import {camposPorPerfil,perfilInfo} from "./CadastroData";
import { validarCadastro } from "../../../auth/AuthValidation";
import {calcStrength,strengthConfig} from "../../../auth/PasswordStrength";
import CadastroFields from "./CadastroFields";
import PasswordFields from "./PasswordFields";
import './cadastro.css';

export default function CadastroPanel({
  perfilSelecionado,
  onVoltarPerfil,
  onSucesso,
  onVoltarLogin,
}) {
  const [step, setStep] = useState(1);

  const [formData, setFormData] = useState({});
  const [errors, setErrors] = useState({});

  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);

  const campos = camposPorPerfil[perfilSelecionado] || [];
  const perfil = perfilInfo[perfilSelecionado];

  function validarPrimeiraEtapa() {
    const novosErros = {};

    campos.forEach(({ name, required }) => {
      if (required && !formData[name]?.trim()) {
        novosErros[name] = "Campo obrigatório.";
      }
    });

    setErrors(novosErros);

    if (Object.keys(novosErros).length === 0) {
      setStep(2);
    }
  }

  function handleSubmit(e) {
    e.preventDefault();

    const novosErros = validarCadastro(
      campos,
      formData,
      password,
      confirmPassword
    );

    setErrors(novosErros);

    if (Object.keys(novosErros).length > 0) return;

    onSucesso(formData.nome);
  }

  return (
    <div className="login-panel">
      <h1>
        Criar <span>conta</span>
      </h1>

      <p className="subtitle">
        Junte-se a uma comunidade que acredita que reciclar é construir um futuro
        melhor.
      </p>

      <button
        className="perfil-badge"
        onClick={onVoltarPerfil}
      >
        Perfil Selecionado: {perfil?.label} | <span>Trocar</span>
      </button>

      <form
        className="cadastro-form"
        onSubmit={handleSubmit}
        noValidate
      >
        {step === 1 && (
          <>
            <CadastroFields
              campos={campos}
              formData={formData}
              errors={errors}
              setFormData={setFormData}
              setErrors={setErrors}
            />

            <div className="cadastro-actions">
              <button
                type="button"
                className="next-button"
                onClick={validarPrimeiraEtapa}
              >
                Continuar
              </button>
            </div>
          </>
        )}

        {step === 2 && (
          <>
            <PasswordFields
              password={password}
              setPassword={setPassword}
              confirmPassword={confirmPassword}
              setConfirmPassword={setConfirmPassword}
              showPassword={showPassword}
              setShowPassword={setShowPassword}
              errors={errors}
              setErrors={setErrors}
            />

            <div className="cadastro-actions">
              <button
                type="submit"
                className="register-button"
              >
                Criar conta
              </button>
            </div>
          </>
        )}
      </form>

      <p className="register">
        Já tem uma conta?{" "}
        <button
          type="button"
          className="link-btn"
          onClick={onVoltarLogin}
        >
          Entrar
        </button>
      </p>
    </div>
  );
}