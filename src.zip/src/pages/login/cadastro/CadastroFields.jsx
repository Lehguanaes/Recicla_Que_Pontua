export default function CadastroFields({
  campos,
  formData,
  errors,
  setFormData,
  setErrors,
}) {
  return (
    <div className="cadastro-fields">
      {campos.map((campo) => (
        <div
          key={campo.name}
          className={`input-group ${
            ["cpf", "dataNascimento", "cidade", "estado"].includes(campo.name)
              ? "half"
              : "full"
          }`}
        >
          <input
            type={campo.type}
            placeholder={campo.placeholder}
            value={formData[campo.name] || ""}
            className={errors[campo.name] ? "error" : ""}
            onChange={(e) => {
              setFormData((prev) => ({
                ...prev,
                [campo.name]: e.target.value,
              }));

              setErrors((prev) => ({
                ...prev,
                [campo.name]: undefined,
              }));
            }}
          />

          {errors[campo.name] && (
            <span className="form-error">
              {errors[campo.name]}
            </span>
          )}
        </div>
      ))}
    </div>
  );
}